	   
	 <br><br>
	 <footer class="text-center text-light bg-dark"  >
	 	
		 <div >
		 	<br> 
		 	<h6>All Right Reserved &copy; Mr.X</h6>
		 	<br>	
		 </div>
		 
	 </footer>
	 
	 <!-- Jquery Calling -->
		<script src="../js/admin.js"></script>
        <script src="../js/jquery-3.2.1.slim.min.js"></script>
	  	<script src="../js/popper.min.js"></script>
	  	<script src="../js/bootstrap.min.js"></script>
	</body>
</html>